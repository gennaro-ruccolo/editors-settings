Emacs client/library for the Language Server Protocol
